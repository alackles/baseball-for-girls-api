"""
seed_players.py
One-time script: download Chadwick Bureau register and populate the players table.
Run once before the draft begins.

Usage:
    python seed_players.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app import create_app
from app.players import seed_from_chadwick

if __name__ == "__main__":
    app = create_app()
    with app.app_context():
        seed_from_chadwick(app)
        print("Done. Player pool is ready.")
